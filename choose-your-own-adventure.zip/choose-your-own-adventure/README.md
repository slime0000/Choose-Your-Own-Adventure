# Choose Your Own Adventure

A Pen created on CodePen.io. Original URL: [https://codepen.io/Madeline-Twombly-Wiser/pen/gOyOVbY](https://codepen.io/Madeline-Twombly-Wiser/pen/gOyOVbY).

